# 🌿 PvZ Novice Server — Guide Replit

## Installation (5 minutes)

### 1. Créer un compte Replit
Va sur **replit.com** et crée un compte gratuit.

### 2. Créer un Repl
- Clique **"Create Repl"**
- Choisis **"Import from GitHub"** OU **"Node.js"**
- Si Node.js : upload les fichiers `server.js` et `package.json`

### 3. Lancer le serveur
- Clique le bouton **"Run"** ▶
- Le serveur démarre sur `https://TON-REPL.TON-USERNAME.repl.co`

### 4. Configurer le jeu
Dans `pvz-novice.html`, cherche la ligne :
```
var SERVER_URL = 'http://localhost:3000';
var WS_URL = 'ws://localhost:3000';
```
Remplace par l'URL de ton Repl :
```
var SERVER_URL = 'https://TON-REPL.TON-USERNAME.repl.co';
var WS_URL = 'wss://TON-REPL.TON-USERNAME.repl.co';
```

## Compte Admin
- **Pseudo :** erkowys
- **Code :** Dandana26
- Créé automatiquement au démarrage du serveur

## Fonctionnalités
- ✅ Inscription / Connexion sécurisée (SHA-256)
- ✅ Chat global temps réel (WebSocket)
- ✅ Système d'amis (demande/accepter/refuser)
- ✅ Joueurs en ligne (dashboard admin)
- ✅ Sauvegarde progression cloud
- ✅ Statuts (menu, en jeu, etc.)
